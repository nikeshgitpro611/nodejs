const connection = require("./dbConncect");

const selectActiveRecord = (sql, sqlParam = null) => {
  // console.log("sqlParam : ", sqlParam);
  return new Promise((resolve, reject) => {
    connection.query(sql, sqlParam, (error, results) => {
      if (error) {
        return reject(error);
      }
      return resolve(results);
    });
  });
};

const getAllDataByDump = async () => {
  let sql = `SELECT * FROM dump limit 10`;
  let result = await selectActiveRecord(sql);
  // console.log(result);
  return result;

  // try {
  //   const rows = await new Promise((resolve, reject) => {
  //     connection.query("SELECT * FROM dump", (err, data) => {
  //       if (err) {
  //         reject(err);
  //       } else {
  //         resolve(data);
  //       }
  //     });
  //   });
  //   return rows;
  // } catch (err) {
  //   console.error("Error:", err);
  //   return [];
  // }
};

const getDataByRequestBodyLocation = async (state) => {
  console.log("State : ", state);
  let sql = `SELECT * FROM dump WHERE assignment_origin = ? `;
  let result = await selectActiveRecord(sql, [state]);
  // console.log(result);

  return result;
};

const getAllDateX = async () => {
  let sql = `select ActualOccurrenceDate from dump limit 10`;
  let result = await selectActiveRecord(sql);
  return result;
};
const getAllDateWindowY = async () => {
  let sql = `select window_size,Counts,Correct from dump limit 10`;
  let result = await selectActiveRecord(sql);
  // console.log(result);

  return result;
};

const getAllDataBasedOnDate = async(dateA, dateB)=>{
  let sql = `SELECT ActualOccurrenceDate,window_size,Counts,Correct FROM dump WHERE ActualOccurrenceDate BETWEEN ? AND ?`;
  let result = await selectActiveRecord(sql,[dateA, dateB]);
  // console.log('Result : ', result);
  return result;
}

// SELECT *
// FROM dump
// WHERE ActualOccurrenceDate BETWEEN '4/1/2024' AND '5/1/2024';

module.exports = {
  getAllDataByDump,
  getDataByRequestBodyLocation,
  getAllDateX,
  getAllDateWindowY,
  getAllDataBasedOnDate
};
