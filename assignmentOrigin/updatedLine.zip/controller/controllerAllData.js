const {
  getAllDataByDump,
  getDataByRequestBodyLocation,
  getAllDateX,
  getAllDateWindowY,
  getAllDataBasedOnDate,
} = require("../helper");

const getAllTyData = async (req, res) => {
  try {
    const data = await getAllDataByDump();
    return res.json({ data });
  } catch (error) {
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

const getDataByLocation = async (req, res) => {
  try {
    const state = req.body.assignment_origin; // Access query parameters
    const data = await getDataByRequestBodyLocation(state);
    return res.json({ data });
  } catch (error) {
    return res.status(500).json({ error: "Internal Server Error" });
  }
};

const getPlotlyWindowAndAccuranceData = async (req, res) => {
  let xData = [];
  let yWindowData = [];
  let yWindowAccuray = [];
  const xAxisDat = await getAllDateX();
  const yWindows = await getAllDateWindowY();

  for (let index = 0; index < xAxisDat.length; index++) {
    const Itrate = xAxisDat[index];
    const itratForYWindow = yWindows[index];
    xData.push(Itrate.ActualOccurrenceDate);
    yWindowData.push(
      (itratForYWindow.window_size / itratForYWindow.Counts).toFixed(2)
    );
    yWindowAccuray.push(
      (itratForYWindow.Correct / itratForYWindow.Counts).toFixed(2)
    );
  }
  // for(let itrat of xAxisDat){
  //   // console.log(itrat.ActualOccurrenceDate);
  //   xData.push(itrat.ActualOccurrenceDate);
  // }
  // for(let itrat of yWindows){
  //   console.log(itrat.window_size);
  //   yWindowData.push(itrat.window_size);
  // }

  if (xData.length > 0) {
    xData.sort();
  }

  const data = {
    x: xData,
    y: {
      Windows: yWindowData,
      Accuracy: yWindowAccuray,
    },
    color: {
      a: "r",
      b: "b",
    },
    label: {
      x: "date",
      y: "Vehicle Count",
    },
    chartType: "line",
  };

  return res
    .json({
      status: true,
      message: "Successfully Message...",
      data: data,
    })
    .status(200);
};

const getAllFilterLineData = async (req, res) => {
  const primeryDate = req.body.primeryDate;
  const secondaryDate = req.body.secondaryDate;
  const getFilterDate = await getAllDataBasedOnDate(primeryDate, secondaryDate);

  let xDate = [];
  let yWindowsSize = [];
  let yAccuracy = [];

  if (xDate.length > 0) {
    xDate.sort((a, b) => new Date(a) - new Date(b))
  }

  for (let index = 0; index < getFilterDate.length; index++) {
    const element = getFilterDate[index];
    const { ActualOccurrenceDate, window_size, Counts, Correct } = element;
    console.log("element : ", element);
    xDate.push(ActualOccurrenceDate);
    yAccuracy.push(Correct / Counts);
    yWindowsSize.push(window_size / Counts);
  }

 

  const data = {
    x: xDate,
    y: {
      Windows: yWindowsSize,
      Accuracy: yAccuracy,
    },
    color: {
      a: "r",
      b: "b",
    },
    label: {
      x: "date",
      y: "Vehicle Count",
    },
    chartType: "line",
  };

  return res.status(200).json({
    status: true,
    message: "Sucess data ♟️",
    data: data,
  });
};

module.exports = {
  getAllTyData,
  getDataByLocation,
  getPlotlyWindowAndAccuranceData,
  getAllFilterLineData,
};
