const express = require("express");
const { getAllTyData, getDataByLocation, getPlotlyWindowAndAccuranceData, getAllFilterLineData } = require("../controller/controllerAllData");
const route = express.Router();

route.get("/", getAllTyData);
route.get("/location", getDataByLocation);
route.get("/plotly", getPlotlyWindowAndAccuranceData);
route.get("/lineGui", getAllFilterLineData)

module.exports = route;
